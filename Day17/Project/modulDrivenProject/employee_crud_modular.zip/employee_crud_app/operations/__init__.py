"""Employee CRUD operations package."""
